# Git Fork in Action

Please watch the Udemy video for this question. No additional information is required.